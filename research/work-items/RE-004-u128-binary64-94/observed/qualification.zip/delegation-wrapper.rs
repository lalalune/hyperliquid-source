#![no_std]
#[inline(never)]
pub fn binary64_bits(n:u128)->u64{ (n as f64).to_bits() }
