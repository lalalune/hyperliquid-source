/tmp/hl-resume-20261101/arithmetic-56c/work/fixed-byte-readers-c1/cargo-target/debug/libnode94_fixed_byte_readers.rlib: /tmp/hl-resume-20261101/arithmetic-56c/src/node94-fixed-byte-readers/lib.rs
